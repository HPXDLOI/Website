const express = require('express');
const cors = require('cors');
const multer = require('multer');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());

// SQLite setup
const db = new sqlite3.Database('./database.db');
db.run(`CREATE TABLE IF NOT EXISTS requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  direction TEXT,
  amount REAL,
  receiver_number TEXT,
  sender_number TEXT,
  trx_id TEXT UNIQUE,
  screenshot TEXT,
  note TEXT,
  fee REAL,
  net_amount REAL,
  status TEXT
)`);

// File upload setup
const storage = multer.diskStorage({
  destination: './uploads/',
  filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname))
});
const upload = multer({ storage });

// API Endpoint
app.post('/api/requests', upload.single('screenshot'), (req, res) => {
  const { direction, amount, receiver_number, sender_number, trx_id_user, note } = req.body;
  const amountNum = parseFloat(amount);
  const fee = amountNum * 0.056; // 5.6%
  const net_amount = amountNum - fee;

  // Check if trx_id exists
  db.get('SELECT * FROM requests WHERE trx_id = ?', [trx_id_user], (err, row) => {
    if (row) return res.status(400).json({ error: 'TRX ID already used' });

    db.run(`INSERT INTO requests(direction, amount, receiver_number, sender_number, trx_id, screenshot, note, fee, net_amount, status)
      VALUES(?,?,?,?,?,?,?,?,?,?)`,
      [direction, amountNum, receiver_number, sender_number, trx_id_user, req.file ? req.file.filename : null, note, fee, net_amount, 'pending'],
      function(err) {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ fee, net_amount, id: this.lastID });
      }
    );
  });
});

app.listen(3000, () => console.log('Backend running on port 3000'));